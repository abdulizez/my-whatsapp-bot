const { extractPureNumber } = require('../haykala/elite');

module.exports = {
  command: 'جماعي',
  category: 'tools',
  description: 'منشن جماعي لكل أعضاء القروب بأسلوب خاص',

  async execute(sock, msg, args = []) {
    try {
      const groupJid = msg.key.remoteJid;

      if (!groupJid.endsWith('@g.us')) {
        return sock.sendMessage(groupJid, { text: '❌ هذا الأمر يعمل فقط في القروبات.' }, { quoted: msg });
      }

      const metadata = await sock.groupMetadata(groupJid);
      const mentions = metadata.participants.map(p => p.id);

      let text = '*𝐀𝐛𝐨 𝐌𝐢𝐥𝐥𝐞𝐫*\n\n';
      for (const member of metadata.participants) {
        const number = extractPureNumber(member.id);
        text += `⛓ @${number} ▬ι𓆃\n`;
      }

      await sock.sendMessage(groupJid, {
        text,
        mentions
      }, { quoted: msg });

    } catch (err) {
      return sock.sendMessage(msg.key.remoteJid, {
        text: `❌ حدث خطأ:\n${err.message || err.toString()}`
      }, { quoted: msg });
    }
  }
};