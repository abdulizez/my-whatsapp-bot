const axios = require('axios');

module.exports = {
  command: 'صور',
  description: 'يجيب لك صورة مرتبطة بالكلمة اللي تكتبها',
  category: 'fun',
  usage: '.صور [كلمة]',

  async execute(sock, msg) {
    try {
      const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text;
      const args = text.split(' ').slice(1);
      if (args.length === 0) {
        await sock.sendMessage(msg.key.remoteJid, { text: 'اكتب كلمة بعد الأمر عشان أجيب لك صورة' }, { quoted: msg });
        return;
      }
      const query = args.join(' ');
      const imageUrl = `https://source.unsplash.com/600x400/?${encodeURIComponent(query)}`;

      // نحمل الصورة
      const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
      const imageBuffer = Buffer.from(response.data, 'binary');

      await sock.sendMessage(msg.key.remoteJid, {
        image: imageBuffer,
        caption: `ها هي صورة لـ "${query}"`
      }, { quoted: msg });

    } catch (error) {
      console.error(error);
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ حصل خطأ أثناء جلب الصورة' }, { quoted: msg });
    }
  }
};