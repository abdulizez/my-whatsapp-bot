const fs = require('fs');

module.exports = {
    command: 'تحرش',
    async execute(sock, m) {
        const chatId = m.key.remoteJid;
        const sender = m.key.participant || m.participant || m.key.remoteJid;

        if (!chatId.endsWith('@g.us')) {
            return sock.sendMessage(chatId, { text: `🚫 هذا الأمر يعمل فقط في *المجموعات*!` });
        }

        const mentionedJids = m.message.extendedTextMessage?.contextInfo?.mentionedJid || [];

        if (mentionedJids.length === 0) {
            return sock.sendMessage(chatId, { text: `❌ استخدم الأمر مع منشن لشخص معين! مثال: *•تحرش @الشخص*` });
        }

        const target = mentionedJids[0];

        const flirtQuotes = [
            "🫦 تخليني؟ ",
            "🫦 تعالي خاص",
           " 🫦 افتحي ", 
            "🫦 اشلحي"
        ];

        const daringQuotes = [
            "🫦 تخليني؟ ",
            "🫦 تعالي خاص",
           " 🫦 افتحي ", 
            "🫦 اشلحي" ];

        const boldQuotes = [
            "🫦 تخليني؟ ",
            "🫦 تعالي خاص",
           " 🫦 افتحي ", 
            "🫦 اشلحي"
        ];

        const allQuotes = [...flirtQuotes, ...daringQuotes, ...boldQuotes];
        const randomQuote = allQuotes[Math.floor(Math.random() * allQuotes.length)];

        const loveMessage = `💍؟ @${target.split('@')[0]}, ${randomQuote}`;
        await sock.sendMessage(chatId, { text: loveMessage, mentions: [target] });
    }
};