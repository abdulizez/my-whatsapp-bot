const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');

module.exports = {
  command: 'تحويل',
  description: 'يحوله من ستيكر إلى صورة',
  category: 'tools',
  usage: '.تحويل (بالرد على ستيكر)',

  async execute(sock, msg) {
    try {
      const quoted = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage;

      if (!quoted?.stickerMessage) {
        await sock.sendMessage(
          msg.key.remoteJid,
          { text: '🛑 لازم ترد على ستيكر عشان أحوله لصورة' },
          { quoted: msg }
        );
        return;
      }

      const buffer = await downloadMediaMessage(
        { message: quoted },
        'buffer',
        {},
        { logger: undefined, reuploadRequest: sock.updateMediaMessage }
      );

      const filePath = './sticker-convert.png';
      fs.writeFileSync(filePath, buffer);

      await sock.sendMessage(
        msg.key.remoteJid,
        { image: fs.readFileSync(filePath), caption: 'انجز ابو الهيثم المهمه' },
        { quoted: msg }
      );

      fs.unlinkSync(filePath);
    } catch (err) {
      console.error(err);
      await sock.sendMessage(
        msg.key.remoteJid,
        { text: '❌ حصل خطأ أثناء التحويل' },
        { quoted: msg }
      );
    }
  }
};