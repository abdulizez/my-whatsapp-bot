
module.exports = {
    command:'.ابو الهيثم شغال؟',
    description: 'اختبار البوت',
    usage: '.ابو الهيثم شغال؟',
    category: '.ابو الهيثم شغال؟ ',    
    
    async execute(sock, msg) {
        try {
            const decoratedText = `ابو الهيثم في الانتظار`;
            await sock.sendMessage(msg.key.remoteJid, {
                text: decoratedText,
                mentions: [msg.sender]
            }, { quoted: msg });
        } catch (error) {
            console.error('❌', 'Error executing test:', error);
            await sock.sendMessage(msg.key.remoteJid, {
                text: responses.error.general(error.message || error.toString())
            }, { quoted: msg });
        }
    }
};