const { downloadMediaMessage } = require('@whiskeysockets/baileys');

module.exports = {
  command: 'ع',
  category: 'عام',
  description: 'عرض الصور والفيديوهات والصوتيات',

  async execute(sock, msg, args = []) {
    try {
      if (!msg.message) {
        return sock.sendMessage(
          msg.key.remoteJid,
          { text: 'لا يمكن العثور على محتوى الرسالة' },
          { quoted: msg }
        );
      }

      const messageType = Object.keys(msg.message)[0];

      if (
        messageType !== 'extendedTextMessage' ||
        !msg.message[messageType]?.contextInfo?.quotedMessage
      ) {
        return sock.sendMessage(
          msg.key.remoteJid,
          { text: 'الرجاء الرد على رسالة بكتابة ع' },
          { quoted: msg }
        );
      }

      let quotedMessage = msg.message[messageType].contextInfo.quotedMessage;

      // التعامل مع الرسائل المؤقتة viewOnce
      if (quotedMessage.viewOnceMessage) {
        quotedMessage = quotedMessage.viewOnceMessage.message;
      }

      const mediaType = Object.keys(quotedMessage)[0];

      if (!['imageMessage', 'videoMessage', 'audioMessage'].includes(mediaType)) {
        return sock.sendMessage(
          msg.key.remoteJid,
          { text: 'هذه الرسالة ليست صورة أو فيديو أو صوت' },
          { quoted: msg }
        );
      }

      const buffer = await downloadMediaMessage(
        {
          message: {
            [mediaType]: quotedMessage[mediaType]
          }
        },
        'buffer',
        {},
        {
          logger: console,
          reuploadRequest: sock.updateMediaMessage
        }
      );

      if (mediaType === 'imageMessage') {
        return sock.sendMessage(
          msg.key.remoteJid,
          {
            image: buffer,
            caption: quotedMessage[mediaType].caption || ''
          },
          { quoted: msg }
        );
      } else if (mediaType === 'videoMessage') {
        return sock.sendMessage(
          msg.key.remoteJid,
          {
            video: buffer,
            caption: quotedMessage[mediaType].caption || ''
          },
          { quoted: msg }
        );
      } else if (mediaType === 'audioMessage') {
        return sock.sendMessage(
          msg.key.remoteJid,
          {
            audio: buffer,
            mimetype: 'audio/mp4'
          },
          { quoted: msg }
        );
      }
    } catch (error) {
      console.error(error); // طبع الخطأ لتعرف السبب
      return sock.sendMessage(
        msg.key.remoteJid,
        { text: 'عذراً، حدث خطأ أثناء معالجة الوسائط' },
        { quoted: msg }
      );
    }
  }
};