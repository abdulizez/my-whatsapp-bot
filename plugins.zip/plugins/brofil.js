module.exports = {
  command: 'بروفايل',
  description: 'يعرض صورة البروفايل للشخص المأمنشن عليه',
  category: 'info',
  usage: '.بروفايل @الاسم',

  async execute(sock, msg) {
    try {
      const mentioned = msg.message.extendedTextMessage?.contextInfo?.mentionedJid;
      if (!mentioned || mentioned.length === 0) {
        await sock.sendMessage(msg.key.remoteJid, { text: '⚠️ لازم تأمنشن على شخص عشان أجيب صورته' }, { quoted: msg });
        return;
      }

      const userJid = mentioned[0];
      // طلب صورة البروفايل بأعلى جودة ممكنة
      const profilePicture = await sock.profilePictureUrl(userJid, 'image').catch(() => null);

      if (!profilePicture) {
        await sock.sendMessage(msg.key.remoteJid, { text: 'ما لقيت صورة للبروفايل حق هذا الشخص' }, { quoted: msg });
        return;
      }

      await sock.sendMessage(msg.key.remoteJid, {
        image: { url: profilePicture },
        caption: `صورة بروفايل لـ @${userJid.split('@')[0]}`
      }, { quoted: msg, mentions: [userJid] });

    } catch (error) {
      console.error(error);
      await sock.sendMessage(msg.key.remoteJid, { text: '❌ حصل خطأ أثناء جلب الصورة' }, { quoted: msg });
    }
  }
};