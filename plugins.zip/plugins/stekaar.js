module.exports = {
    command: "ستيكر",
    description: "تحويل الفيديو القصير إلى ستيكر",
    usage: ".ستيكر (رد على فيديو قصير)",
    category: "fun",

    async execute(sock, msg) {
        const jid = msg.key.remoteJid;

        // نجرب نلقط الفيديو سواء مباشر أو رد
        let videoMessage = msg.message?.videoMessage;

        if (!videoMessage && msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.videoMessage) {
            videoMessage = msg.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage;
        }

        // لو مافي فيديو
        if (!videoMessage) {
            return await sock.sendMessage(jid, {
                text: "❗ استخدم الأمر بالرد على فيديو قصير."
            }, { quoted: msg });
        }

        // نتحقق من الطول
        if (videoMessage.seconds > 10) {
            return await sock.sendMessage(jid, {
                text: "⚠️ الفيديو طويل! استخدم فيديو قصير أقل من 10 ثواني."
            }, { quoted: msg });
        }

        try {
            // ننزل الفيديو (سواء مباشر أو من الرد)
            const buffer = await sock.downloadMediaMessage(
                msg.message?.videoMessage
                    ? msg
                    : { message: { videoMessage }, ...msg } // نركب الرسالة لو كانت رد
            );

            // نرسله كستيكر
            await sock.sendMessage(jid, {
                sticker: buffer
            }, { quoted: msg });
        } catch (err) {
            console.error("خطأ أثناء التحويل إلى ستيكر:", err);
            await sock.sendMessage(jid, {
                text: "❌ فشل تحويل الفيديو إلى ستيكر."
            }, { quoted: msg });
        }
    }
};