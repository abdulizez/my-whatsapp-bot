function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

module.exports = {
  command: 'سبام',
  description: 'يرسل رسالة 50 مرة بسرعة مع تأخير بسيط',
  category: 'fun',
  usage: '.سبام',

  async execute(sock, msg) {
    const text = ' سبام! 🧨';
    for (let i = 0; i < 50; i++) {
      await sock.sendMessage(msg.key.remoteJid, { text });
      await delay(700);  // تأخير 700 مللي ثانية
    }
  }
};